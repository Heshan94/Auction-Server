we are group 23(E/13/319, E/13/106) and instructions to use this application explained bellow.

1.first run codes using "javac .*java"
2. secondly, run the "AuctionServer.class"
3. For search bidding history, type text box on bottom of the GUI symbol you want search, like FB, VRTU, MSFT, GOOGL,YHOO etc.